jui_theme_switch
================

jui_theme_switch is a jquery plugin, displays a list of jquery-ui css themes and applies selected theme.

Project page: [https://pontikis.net/labs/jui_theme_switch][HOME]
[HOME]: http://pontikis.net/labs/jui_theme_switch

Copyright Christos Pontikis [http://pontikis.net][copyright]
[copyright]: http://pontikis.net

License MIT


Release 1.0.6 (21 Jan 2013)
---------------------------
* minor changes (keywords in package.json manifest must not contain spaces!)


Release 1.0.5 (21 Jan 2013)
---------------------------
* minor changes


Release 1.0.4 (21 Jan 2013)
---------------------------
* minor changes


Release 1.0.3 (21 Jan 2013)
---------------------------
* minor changes


Release 1.0.2 (21 Jan 2013)
---------------------------
* minor changes


Release 1.0.1 (21 Jan 2013)
---------------------------
* minor changes


Release 1.0.0 (29 Dec 2012)
---------------------------
* Displays a list with jquery ui css and applies selected
